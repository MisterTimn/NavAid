/* 
 * File:   main.cpp
 * Author: g
 *
 * Created on May 15, 2014, 11:35 AM
 */

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>


using namespace std;
using namespace cv;

struct Location {
    vector<string> trainFiles;
    vector<string> programNames;
    string locationName;
    // evt.. directions
};
vector<Location> locations(5);
int currentLocation;
bool reverse;

double useSVM(const string & trainingFile, const string & testDataFile, const string & resultFile) {
    const string command = "./svm_perf_classify " + testDataFile + " " + trainingFile + " " + resultFile;
    system(command.c_str());
    ifstream myfile;
    myfile.open(resultFile.c_str());
    string line;
    if (myfile.is_open()) {
        //while (getline(myfile, line)) {
        getline(myfile, line);
        cout << line << '\n';
        myfile.close();
        return atof(line.c_str());
        //}
    } else {
        cout << "Could not open: " + resultFile;
        return 0;
    }
}

void callFeatureDetection(const string & programName, const string & imagePath, const string & outputFile) {
    const string command = "./" + programName + " " + imagePath + " " + outputFile;
    system(command.c_str());
}

void mainFunction(Mat & src) {

    const string photoName = "testImage.jpg";
    // save image to file so other programs can open it... 
    imwrite(photoName, src);

    //namedWindow("pic");
    //imshow("pic", src);
    //if (waitKey(1000.0 / video.get(CV_CAP_PROP_FPS)) >= 0) {
    //    break;
    //}
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < locations[i].programNames.size(); j++) {
            callFeatureDetection(locations[i].programNames[j], photoName, locations[i].programNames[j] + ".testdata");
            double sterkte = useSVM(locations[i].trainFiles[j], locations[i].programNames[j] + ".testdata", "result"+ locations[i].programNames[j]);
            if (sterkte > 0.5) {
                cout << "true!";
            } else if (sterkte < -0.5) {
                cout << "false! ";
            } else {
                cout << "unsure...";
            }
        }
    }
//    namedWindow("test");
//    imshow("test", src);
//    waitKey(0);
    //const string trainingFile = "model";
    //const string testDataFile = "train_goood.dat";
    //const string resultFile = "predictions";
    //    double sterkte = useSVM(trainingFile, testDataFile, resultFile);
    //    if (sterkte > 0.5) {
    //        cout << "true!";
    //    } else if (sterkte < -0.5) {
    //        cout << "false! ";
    //    } else {
    //        cout << "unsure...";
    //    }
}

void initialiseParameters() {

    Location loc1;
    loc1.locationName = "Betonpad aan station.";
    loc1.programNames.push_back("BetonDetector");
    for (int i = 0; i < loc1.programNames.size(); i++) {
        loc1.trainFiles.push_back("model" + loc1.programNames[i]);
    }
    Location loc2;
    loc2.locationName = "Tegelstructuren tussen station en oprit.";
    Location loc3;
    loc3.locationName = "Tegelstructuur tussen oprit en sportgebouw.";
    Location loc4;
    loc4.locationName = "Tegelstructuur naast het sportgebouw.";
    Location loc5;
    loc5.locationName = "Gras tussen sporthal en p-gebouw.";
    // add programnames and trainingFileNames
    locations[0] = loc1;
    locations[1] = loc2;
    locations[2] = loc3;
    locations[3] = loc4;
    locations[4] = loc5;
}

/*
 * 
 */
int main(int argc, char** argv) {
    //system("./svm_perf_learn -c 20 -l 2 /home/g/Downloads/predictions.dat model");

    string videoPath = "/home/g/Downloads/20140305_h_10fps.avi"; //20140226_h_10fps.avi"

    initialiseParameters();

    int count = 0;
    VideoCapture video(videoPath);
    Mat src;
    if (video.isOpened()) {
        while (video.read(src)) {
            if (count % 49 == 0) {
                mainFunction(src);
            }
            count++;
        }
    }
    return 0;
}

